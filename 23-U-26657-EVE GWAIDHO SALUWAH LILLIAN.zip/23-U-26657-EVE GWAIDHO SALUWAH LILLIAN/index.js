
function validateCredentials(email,password){
    const validEmail="gwaidhosaluwahlillian@gmail.com";
    const validPassword ="23-U-26657-EVE@2024";

    if(email===validEmail && password===validPassword){
         console.log(" User emal is{email}, login successfully!");
    } else{
        console.log('incorrect user credentials');
    }
}
validateCredentials("gwaidhosaluwahlillian@gmail.com" , "23-U-26657-EVE@2024")


